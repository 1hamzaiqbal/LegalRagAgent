Upload this zip to Overleaf and compile main.tex. The zip includes main.tex, references.bib, neurips_2024.sty, rendered figures, and a preview PDF.
